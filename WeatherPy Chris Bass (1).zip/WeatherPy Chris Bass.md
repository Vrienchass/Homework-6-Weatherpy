

```python
#Observations
#1 Max temperature of cities is clearly related to proximity to the equator. In particular, from about -10 - 30' latitude appears to have similar temperatures. As cities are located further outside of these latitudinal lines, they have lower temperatures.
#2 There is an abundance of clouds in cities closer to the equator. There are no cities in my data set in the latitudes immediately surrounding the equator with 0 cloud cover. Cities further fromt he equator have more varied cloud cover.
#3 Cities close to the equator are very likely to have high humidity. Whereas cities further from the equator have more varied amounts of humidity. In particular, cities between the 20' and 40' latititudes are more likely to have the least humidity. 
```


```python
from citipy import citipy
import random
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import requests
import json

#http://desktop.arcgis.com/en/arcmap/10.3/
#guide-books/map-projections/about-geographic-coordinate-systems.htm
```


```python
#create lists to hold names of cities and countries 
random_city = []
random_country = []
loopcount = 0 
#loop through cities to get 650 random city names 
while len(random_city) < 650:
    loopcount += 1 

    lat_position = random.randint(0,2)
    base_lat = random.randint(0,91)
    dec_lat = random.random()/100
    lat = base_lat + dec_lat 
    if lat_position == 1:
        lat = lat * -1
    #print(f"The latitude is:{lat}")
    lng_position = random.randint(0,2)
    base_long = random.randint(0,181)
    dec_long = random.random()/100
    lng = base_long + dec_long 
    if lng_position == 1:
        lng = lng * -1
    #print(f"The longitude is:{long}")
    
    #use citipy to get nearest city using lat and long
    city = citipy.nearest_city(lat, lng)
    foundCity = False
    for x in range(len(random_city)):
        if city.city_name == random_city[x]:
            foundCity = True
    if foundCity==False:
        random_city.append(city.city_name)
        random_country.append(city.country_code)
```


```python
# Build query Url# Build 
base_url = "http://api.openweathermap.org/data/2.5/weather?"
api_key = "a515ea15c873b3e2ab6ca4f1c00f8fd0"
units = "imperial"
query_url = base_url + "appid=" + api_key + "&units=" + units + "&q="
```


```python
# Loop through list and make requests 
search_data = []
cityList = []
countryList = []

searchCnt = 0
for city in random_city:
    searchCnt += 1
    print(f"Processing record {searchCnt} for the city: {city}")   
    response = requests.get(query_url + city).json()
    searchCityID = response.get("id")
    if response.get("id"):
        print(f"     Record found for city: {city}    city id: {searchCityID}")
        search_data.append(response)
        cityList.append(city)
        countryList.append(random_country[searchCnt-1])
    else:
        print(f"     No weather record found for city: {city}")    
        print("************************************************")
```

    Processing record 1 for the city: gobabis
         Record found for city: gobabis    city id: 3357247
    Processing record 2 for the city: nadym
         Record found for city: nadym    city id: 1498087
    Processing record 3 for the city: santa cruz
         Record found for city: santa cruz    city id: 5393052
    Processing record 4 for the city: hobart
         Record found for city: hobart    city id: 2163355
    Processing record 5 for the city: amderma
         No weather record found for city: amderma
    ************************************************
    Processing record 6 for the city: pevek
         Record found for city: pevek    city id: 2122090
    Processing record 7 for the city: bur gabo
         No weather record found for city: bur gabo
    ************************************************
    Processing record 8 for the city: jamestown
         Record found for city: jamestown    city id: 2069194
    Processing record 9 for the city: nikolskoye
         Record found for city: nikolskoye    city id: 546105
    Processing record 10 for the city: illoqqortoormiut
         No weather record found for city: illoqqortoormiut
    ************************************************
    Processing record 11 for the city: carnarvon
         Record found for city: carnarvon    city id: 1014034
    Processing record 12 for the city: dikson
         Record found for city: dikson    city id: 1507390
    Processing record 13 for the city: fortuna
         Record found for city: fortuna    city id: 2517679
    Processing record 14 for the city: rensvik
         Record found for city: rensvik    city id: 6453331
    Processing record 15 for the city: vila franca do campo
         Record found for city: vila franca do campo    city id: 3372472
    Processing record 16 for the city: bud
         Record found for city: bud    city id: 7626370
    Processing record 17 for the city: albany
         Record found for city: albany    city id: 5106834
    Processing record 18 for the city: neftcala
         Record found for city: neftcala    city id: 147425
    Processing record 19 for the city: talnakh
         Record found for city: talnakh    city id: 1490256
    Processing record 20 for the city: taolanaro
         No weather record found for city: taolanaro
    ************************************************
    Processing record 21 for the city: sri aman
         Record found for city: sri aman    city id: 1735799
    Processing record 22 for the city: new norfolk
         Record found for city: new norfolk    city id: 2155415
    Processing record 23 for the city: butaritari
         Record found for city: butaritari    city id: 2110227
    Processing record 24 for the city: ushuaia
         Record found for city: ushuaia    city id: 3833367
    Processing record 25 for the city: kiunga
         Record found for city: kiunga    city id: 2093846
    Processing record 26 for the city: cotonou
         Record found for city: cotonou    city id: 2394819
    Processing record 27 for the city: sisimiut
         Record found for city: sisimiut    city id: 3419842
    Processing record 28 for the city: puerto ayora
         Record found for city: puerto ayora    city id: 3652764
    Processing record 29 for the city: tevriz
         Record found for city: tevriz    city id: 1489661
    Processing record 30 for the city: mataura
         Record found for city: mataura    city id: 6201424
    Processing record 31 for the city: nizhneyansk
         No weather record found for city: nizhneyansk
    ************************************************
    Processing record 32 for the city: chardara
         No weather record found for city: chardara
    ************************************************
    Processing record 33 for the city: nanhai
         Record found for city: nanhai    city id: 7696234
    Processing record 34 for the city: kjopsvik
         Record found for city: kjopsvik    city id: 3150002
    Processing record 35 for the city: arraial do cabo
         Record found for city: arraial do cabo    city id: 3471451
    Processing record 36 for the city: semnan
         Record found for city: semnan    city id: 116402
    Processing record 37 for the city: yamada
         Record found for city: yamada    city id: 1849876
    Processing record 38 for the city: zhigansk
         Record found for city: zhigansk    city id: 2012530
    Processing record 39 for the city: college
         Record found for city: college    city id: 5859699
    Processing record 40 for the city: bafra
         No weather record found for city: bafra
    ************************************************
    Processing record 41 for the city: tigil
         Record found for city: tigil    city id: 2120612
    Processing record 42 for the city: wamba
         Record found for city: wamba    city id: 204318
    Processing record 43 for the city: oshnaviyeh
         Record found for city: oshnaviyeh    city id: 121795
    Processing record 44 for the city: havelock
         Record found for city: havelock    city id: 4470244
    Processing record 45 for the city: eldikan
         No weather record found for city: eldikan
    ************************************************
    Processing record 46 for the city: hilo
         Record found for city: hilo    city id: 5855927
    Processing record 47 for the city: kapaa
         Record found for city: kapaa    city id: 5848280
    Processing record 48 for the city: busselton
         Record found for city: busselton    city id: 2075265
    Processing record 49 for the city: mar del plata
         Record found for city: mar del plata    city id: 3863379
    Processing record 50 for the city: khatanga
         Record found for city: khatanga    city id: 2022572
    Processing record 51 for the city: tuy hoa
         Record found for city: tuy hoa    city id: 1563281
    Processing record 52 for the city: rudnogorsk
         Record found for city: rudnogorsk    city id: 2017378
    Processing record 53 for the city: madera
         Record found for city: madera    city id: 5369568
    Processing record 54 for the city: bokoro
         No weather record found for city: bokoro
    ************************************************
    Processing record 55 for the city: decatur
         Record found for city: decatur    city id: 4617650
    Processing record 56 for the city: zhangjiakou
         Record found for city: zhangjiakou    city id: 2033196
    Processing record 57 for the city: vardo
         Record found for city: vardo    city id: 4372777
    Processing record 58 for the city: grootfontein
         Record found for city: grootfontein    city id: 3357114
    Processing record 59 for the city: sakakah
         No weather record found for city: sakakah
    ************************************************
    Processing record 60 for the city: chokurdakh
         Record found for city: chokurdakh    city id: 2126123
    Processing record 61 for the city: iqaluit
         Record found for city: iqaluit    city id: 5983720
    Processing record 62 for the city: cape town
         Record found for city: cape town    city id: 3369157
    Processing record 63 for the city: codrington
         Record found for city: codrington    city id: 2160063
    Processing record 64 for the city: roald
         Record found for city: roald    city id: 3141667
    Processing record 65 for the city: assela
         No weather record found for city: assela
    ************************************************
    Processing record 66 for the city: djougou
         Record found for city: djougou    city id: 2394560
    Processing record 67 for the city: matara
         Record found for city: matara    city id: 3948642
    Processing record 68 for the city: barentsburg
         No weather record found for city: barentsburg
    ************************************************
    Processing record 69 for the city: port elizabeth
         Record found for city: port elizabeth    city id: 4501427
    Processing record 70 for the city: saint anthony
         Record found for city: saint anthony    city id: 5606187
    Processing record 71 for the city: anadyr
         Record found for city: anadyr    city id: 2127202
    Processing record 72 for the city: saint george
         Record found for city: saint george    city id: 262462
    Processing record 73 for the city: norman wells
         Record found for city: norman wells    city id: 6089245
    Processing record 74 for the city: severo-kurilsk
         Record found for city: severo-kurilsk    city id: 2121385
    Processing record 75 for the city: fuxin
         Record found for city: fuxin    city id: 2037346
    Processing record 76 for the city: ontario
         Record found for city: ontario    city id: 5379439
    Processing record 77 for the city: ozgon
         No weather record found for city: ozgon
    ************************************************
    Processing record 78 for the city: tumannyy
         No weather record found for city: tumannyy
    ************************************************
    Processing record 79 for the city: punta arenas
         Record found for city: punta arenas    city id: 3874787
    Processing record 80 for the city: komsomolskiy
         Record found for city: komsomolskiy    city id: 1486910
    Processing record 81 for the city: shingu
         Record found for city: shingu    city id: 1847947
    Processing record 82 for the city: blenheim
         Record found for city: blenheim    city id: 6243926
    Processing record 83 for the city: port blair
         Record found for city: port blair    city id: 1259385
    Processing record 84 for the city: baykit
         Record found for city: baykit    city id: 1510689
    Processing record 85 for the city: mirabad
         Record found for city: mirabad    city id: 1160571
    Processing record 86 for the city: klyuchevskiy
         Record found for city: klyuchevskiy    city id: 2021980
    Processing record 87 for the city: kamenskoye
         No weather record found for city: kamenskoye
    ************************************************
    Processing record 88 for the city: umm lajj
         Record found for city: umm lajj    city id: 100926
    Processing record 89 for the city: okha
         Record found for city: okha    city id: 2122614
    Processing record 90 for the city: christchurch
         Record found for city: christchurch    city id: 2192362
    Processing record 91 for the city: oskemen
         Record found for city: oskemen    city id: 1520316
    Processing record 92 for the city: elko
         Record found for city: elko    city id: 5703670
    Processing record 93 for the city: ishlei
         No weather record found for city: ishlei
    ************************************************
    Processing record 94 for the city: mangai
         Record found for city: mangai    city id: 2313084
    Processing record 95 for the city: belushya guba
         No weather record found for city: belushya guba
    ************************************************
    Processing record 96 for the city: aklavik
         Record found for city: aklavik    city id: 5882953
    Processing record 97 for the city: palivere
         Record found for city: palivere    city id: 588015
    Processing record 98 for the city: palabuhanratu
         No weather record found for city: palabuhanratu
    ************************************************
    Processing record 99 for the city: buraydah
         Record found for city: buraydah    city id: 107304
    Processing record 100 for the city: takoradi
         Record found for city: takoradi    city id: 2294915
    Processing record 101 for the city: margate
         Record found for city: margate    city id: 2158744
    Processing record 102 for the city: warkworth
         Record found for city: warkworth    city id: 2179639
    Processing record 103 for the city: avarua
         Record found for city: avarua    city id: 4035715
    Processing record 104 for the city: tiksi
         Record found for city: tiksi    city id: 2015306
    Processing record 105 for the city: am timan
         Record found for city: am timan    city id: 245338
    Processing record 106 for the city: san patricio
         Record found for city: san patricio    city id: 3437029
    Processing record 107 for the city: seoul
         Record found for city: seoul    city id: 1835848
    Processing record 108 for the city: grand centre
         No weather record found for city: grand centre
    ************************************************
    Processing record 109 for the city: mys shmidta
         No weather record found for city: mys shmidta
    ************************************************
    Processing record 110 for the city: tessalit
         Record found for city: tessalit    city id: 2449893
    Processing record 111 for the city: biak
         Record found for city: biak    city id: 1637001
    Processing record 112 for the city: dongsheng
         Record found for city: dongsheng    city id: 1788268
    Processing record 113 for the city: luocheng
         Record found for city: luocheng    city id: 7690142
    Processing record 114 for the city: brumunddal
         Record found for city: brumunddal    city id: 3159894
    Processing record 115 for the city: fairbanks
         Record found for city: fairbanks    city id: 5861897
    Processing record 116 for the city: leningradskiy
         Record found for city: leningradskiy    city id: 2123814
    Processing record 117 for the city: chapel hill
         Record found for city: chapel hill    city id: 4460162
    Processing record 118 for the city: thompson
         Record found for city: thompson    city id: 6165406
    Processing record 119 for the city: gazojak
         Record found for city: gazojak    city id: 1514792
    Processing record 120 for the city: werneck
         Record found for city: werneck    city id: 2810832
    Processing record 121 for the city: saskylakh
         Record found for city: saskylakh    city id: 2017155
    Processing record 122 for the city: lebu
         Record found for city: lebu    city id: 344979
    Processing record 123 for the city: hermanus
         Record found for city: hermanus    city id: 3366880
    Processing record 124 for the city: makakilo city
         Record found for city: makakilo city    city id: 5850554
    Processing record 125 for the city: cidreira
         Record found for city: cidreira    city id: 3466165
    Processing record 126 for the city: barrow
         Record found for city: barrow    city id: 3833859
    Processing record 127 for the city: saint-philippe
         Record found for city: saint-philippe    city id: 6138908
    Processing record 128 for the city: georgetown
         Record found for city: georgetown    city id: 3378644
    Processing record 129 for the city: kaabong
         Record found for city: kaabong    city id: 233093
    Processing record 130 for the city: tuktoyaktuk
         Record found for city: tuktoyaktuk    city id: 6170031
    Processing record 131 for the city: marawi
         Record found for city: marawi    city id: 1701054
    Processing record 132 for the city: east london
         Record found for city: east london    city id: 1006984
    Processing record 133 for the city: kavieng
         Record found for city: kavieng    city id: 2094342
    Processing record 134 for the city: vaini
         Record found for city: vaini    city id: 1273574
    Processing record 135 for the city: airai
         Record found for city: airai    city id: 1651810
    Processing record 136 for the city: bluff
         Record found for city: bluff    city id: 2175403
    Processing record 137 for the city: tasiilaq
         Record found for city: tasiilaq    city id: 3424607
    Processing record 138 for the city: egvekinot
         Record found for city: egvekinot    city id: 4031742
    Processing record 139 for the city: south lake tahoe
         Record found for city: south lake tahoe    city id: 5397664
    Processing record 140 for the city: aktash
         No weather record found for city: aktash
    ************************************************
    Processing record 141 for the city: ribeira grande
         Record found for city: ribeira grande    city id: 3372707
    Processing record 142 for the city: bilma
         Record found for city: bilma    city id: 2446796
    Processing record 143 for the city: valdivia
         Record found for city: valdivia    city id: 3868707
    Processing record 144 for the city: ajoloapan
         No weather record found for city: ajoloapan
    ************************************************
    Processing record 145 for the city: mitchell
         Record found for city: mitchell    city id: 5229794
    Processing record 146 for the city: mogadishu
         Record found for city: mogadishu    city id: 53654
    Processing record 147 for the city: luganville
         Record found for city: luganville    city id: 2136150
    Processing record 148 for the city: pula
         Record found for city: pula    city id: 3658053
    Processing record 149 for the city: longyearbyen
         Record found for city: longyearbyen    city id: 2729907
    Processing record 150 for the city: mbekenyera
         Record found for city: mbekenyera    city id: 878006
    Processing record 151 for the city: digras
         Record found for city: digras    city id: 1272596
    Processing record 152 for the city: qaanaaq
         Record found for city: qaanaaq    city id: 3831208
    Processing record 153 for the city: hofn
         Record found for city: hofn    city id: 2630299
    Processing record 154 for the city: fort-shevchenko
         Record found for city: fort-shevchenko    city id: 609906
    Processing record 155 for the city: dharur
         Record found for city: dharur    city id: 1272819
    Processing record 156 for the city: constitucion
         Record found for city: constitucion    city id: 4011743
    Processing record 157 for the city: thinadhoo
         Record found for city: thinadhoo    city id: 1337610
    Processing record 158 for the city: hithadhoo
         Record found for city: hithadhoo    city id: 1282256
    Processing record 159 for the city: karpathos
         Record found for city: karpathos    city id: 260895
    Processing record 160 for the city: bolshaya vishera
         No weather record found for city: bolshaya vishera
    ************************************************
    Processing record 161 for the city: hambantota
         Record found for city: hambantota    city id: 1244926
    Processing record 162 for the city: albion
         Record found for city: albion    city id: 5062806
    Processing record 163 for the city: vostok
         Record found for city: vostok    city id: 2013279
    Processing record 164 for the city: brae
         Record found for city: brae    city id: 2654970
    Processing record 165 for the city: anito
         Record found for city: anito    city id: 1730622
    Processing record 166 for the city: abu dhabi
         Record found for city: abu dhabi    city id: 292968
    Processing record 167 for the city: port moresby
         Record found for city: port moresby    city id: 2088122
    Processing record 168 for the city: klaksvik
         Record found for city: klaksvik    city id: 2618795
    Processing record 169 for the city: tyrma
         Record found for city: tyrma    city id: 2014694
    Processing record 170 for the city: cherskiy
         Record found for city: cherskiy    city id: 2126199
    Processing record 171 for the city: sar-e pul
         Record found for city: sar-e pul    city id: 1127110
    Processing record 172 for the city: khonuu
         No weather record found for city: khonuu
    ************************************************
    Processing record 173 for the city: lavrentiya
         Record found for city: lavrentiya    city id: 4031637
    Processing record 174 for the city: port augusta
         Record found for city: port augusta    city id: 2063056
    Processing record 175 for the city: bani walid
         Record found for city: bani walid    city id: 2218840
    Processing record 176 for the city: rungata
         No weather record found for city: rungata
    ************************************************
    Processing record 177 for the city: rosetta
         Record found for city: rosetta    city id: 350203
    Processing record 178 for the city: khonsa
         Record found for city: khonsa    city id: 1266668
    Processing record 179 for the city: gat
         Record found for city: gat    city id: 2249901
    Processing record 180 for the city: ulkan
         Record found for city: ulkan    city id: 2020208
    Processing record 181 for the city: ibra
         Record found for city: ibra    city id: 287832
    Processing record 182 for the city: muli
         Record found for city: muli    city id: 1256929
    Processing record 183 for the city: sendafa
         Record found for city: sendafa    city id: 328880
    Processing record 184 for the city: hobyo
         Record found for city: hobyo    city id: 57000
    Processing record 185 for the city: jalu
         Record found for city: jalu    city id: 86049
    Processing record 186 for the city: ahipara
         Record found for city: ahipara    city id: 2194098
    Processing record 187 for the city: yellowknife
         Record found for city: yellowknife    city id: 6185377
    Processing record 188 for the city: huilong
         Record found for city: huilong    city id: 1795424
    Processing record 189 for the city: shwebo
         Record found for city: shwebo    city id: 1296736
    Processing record 190 for the city: thayetmyo
         Record found for city: thayetmyo    city id: 1292037
    Processing record 191 for the city: alice springs
         Record found for city: alice springs    city id: 2077895
    Processing record 192 for the city: berlevag
         Record found for city: berlevag    city id: 780687
    Processing record 193 for the city: atambua
         Record found for city: atambua    city id: 1651103
    Processing record 194 for the city: port alfred
         Record found for city: port alfred    city id: 964432
    Processing record 195 for the city: umzimvubu
         No weather record found for city: umzimvubu
    ************************************************
    Processing record 196 for the city: upernavik
         Record found for city: upernavik    city id: 3418910
    Processing record 197 for the city: kaitangata
         Record found for city: kaitangata    city id: 2208248
    Processing record 198 for the city: narsaq
         Record found for city: narsaq    city id: 3421719
    Processing record 199 for the city: takayama
         Record found for city: takayama    city id: 1850892
    Processing record 200 for the city: sao filipe
         Record found for city: sao filipe    city id: 3374210
    Processing record 201 for the city: pala
         Record found for city: pala    city id: 1272022
    Processing record 202 for the city: alihe
         Record found for city: alihe    city id: 2038665
    Processing record 203 for the city: aguimes
         Record found for city: aguimes    city id: 2522325
    Processing record 204 for the city: svetlaya
         Record found for city: svetlaya    city id: 2015852
    Processing record 205 for the city: hasaki
         Record found for city: hasaki    city id: 2112802
    Processing record 206 for the city: taburao
         No weather record found for city: taburao
    ************************************************
    Processing record 207 for the city: vestmannaeyjar
         Record found for city: vestmannaeyjar    city id: 3412093
    Processing record 208 for the city: kaeo
         Record found for city: kaeo    city id: 2189343
    Processing record 209 for the city: bilibino
         Record found for city: bilibino    city id: 2126682
    Processing record 210 for the city: castro
         Record found for city: castro    city id: 3896218
    Processing record 211 for the city: yumen
         Record found for city: yumen    city id: 1528998
    Processing record 212 for the city: mandera
         Record found for city: mandera    city id: 187896
    Processing record 213 for the city: geraldton
         Record found for city: geraldton    city id: 5960603
    Processing record 214 for the city: nanortalik
         Record found for city: nanortalik    city id: 3421765
    Processing record 215 for the city: victoria
         Record found for city: victoria    city id: 1733782
    Processing record 216 for the city: bacolod
         Record found for city: bacolod    city id: 1729564
    Processing record 217 for the city: kulhudhuffushi
         Record found for city: kulhudhuffushi    city id: 1337613
    Processing record 218 for the city: babstovo
         Record found for city: babstovo    city id: 2027277
    Processing record 219 for the city: turan
         Record found for city: turan    city id: 1488950
    Processing record 220 for the city: skiros
         No weather record found for city: skiros
    ************************************************
    Processing record 221 for the city: waipawa
         Record found for city: waipawa    city id: 2185329
    Processing record 222 for the city: bambous virieux
         Record found for city: bambous virieux    city id: 1106677
    Processing record 223 for the city: faya
         Record found for city: faya    city id: 110690
    Processing record 224 for the city: esperance
         Record found for city: esperance    city id: 3573739
    Processing record 225 for the city: moissala
         Record found for city: moissala    city id: 2427697
    Processing record 226 for the city: constantine
         Record found for city: constantine    city id: 2501152
    Processing record 227 for the city: bredasdorp
         Record found for city: bredasdorp    city id: 1015776
    Processing record 228 for the city: nongpoh
         Record found for city: nongpoh    city id: 1261208
    Processing record 229 for the city: alotau
         No weather record found for city: alotau
    ************************************************
    Processing record 230 for the city: lewistown
         Record found for city: lewistown    city id: 4899665
    Processing record 231 for the city: caravelas
         Record found for city: caravelas    city id: 3466980
    Processing record 232 for the city: misratah
         Record found for city: misratah    city id: 2214846
    Processing record 233 for the city: lata
         Record found for city: lata    city id: 1253628
    Processing record 234 for the city: pella
         Record found for city: pella    city id: 4870915
    Processing record 235 for the city: bengkulu
         No weather record found for city: bengkulu
    ************************************************
    Processing record 236 for the city: yaan
         Record found for city: yaan    city id: 2338660
    Processing record 237 for the city: mahadday weyne
         No weather record found for city: mahadday weyne
    ************************************************
    Processing record 238 for the city: te anau
         Record found for city: te anau    city id: 2181625
    Processing record 239 for the city: samarai
         Record found for city: samarai    city id: 2132606
    Processing record 240 for the city: amantea
         Record found for city: amantea    city id: 2525727
    Processing record 241 for the city: touros
         Record found for city: touros    city id: 3386213
    Processing record 242 for the city: potsdam
         Record found for city: potsdam    city id: 2852458
    Processing record 243 for the city: tura
         Record found for city: tura    city id: 1254046
    Processing record 244 for the city: guilin
         Record found for city: guilin    city id: 1809498
    Processing record 245 for the city: sidi bu zayd
         No weather record found for city: sidi bu zayd
    ************************************************
    Processing record 246 for the city: bardiyah
         No weather record found for city: bardiyah
    ************************************************
    Processing record 247 for the city: casablanca
         Record found for city: casablanca    city id: 2553604
    Processing record 248 for the city: barsovo
         Record found for city: barsovo    city id: 1510842
    Processing record 249 for the city: lingao
         Record found for city: lingao    city id: 1803560
    Processing record 250 for the city: kaseda
         Record found for city: kaseda    city id: 1859964
    Processing record 251 for the city: tsihombe
         No weather record found for city: tsihombe
    ************************************************
    Processing record 252 for the city: tarudant
         No weather record found for city: tarudant
    ************************************************
    Processing record 253 for the city: fuling
         Record found for city: fuling    city id: 1810979
    Processing record 254 for the city: oistins
         Record found for city: oistins    city id: 3373652
    Processing record 255 for the city: mitha tiwana
         Record found for city: mitha tiwana    city id: 1170222
    Processing record 256 for the city: staryy krym
         Record found for city: staryy krym    city id: 692714
    Processing record 257 for the city: hlotse
         No weather record found for city: hlotse
    ************************************************
    Processing record 258 for the city: bethel
         Record found for city: bethel    city id: 5880568
    Processing record 259 for the city: zalaszentgrot
         Record found for city: zalaszentgrot    city id: 3042603
    Processing record 260 for the city: alta floresta
         Record found for city: alta floresta    city id: 6316343
    Processing record 261 for the city: cockburn town
         Record found for city: cockburn town    city id: 3576994
    Processing record 262 for the city: luderitz
         Record found for city: luderitz    city id: 3355672
    Processing record 263 for the city: saryshagan
         No weather record found for city: saryshagan
    ************************************************
    Processing record 264 for the city: birjand
         Record found for city: birjand    city id: 140463
    Processing record 265 for the city: attawapiskat
         No weather record found for city: attawapiskat
    ************************************************
    Processing record 266 for the city: cumaribo
         No weather record found for city: cumaribo
    ************************************************
    Processing record 267 for the city: rikitea
         Record found for city: rikitea    city id: 4030556
    Processing record 268 for the city: belyy yar
         Record found for city: belyy yar    city id: 1510377
    Processing record 269 for the city: patnos
         Record found for city: patnos    city id: 302819
    Processing record 270 for the city: shizunai
         Record found for city: shizunai    city id: 2128025
    Processing record 271 for the city: dwarka
         Record found for city: dwarka    city id: 1273294
    Processing record 272 for the city: sentyabrskiy
         No weather record found for city: sentyabrskiy
    ************************************************
    Processing record 273 for the city: tambacounda
         Record found for city: tambacounda    city id: 2244991
    Processing record 274 for the city: pangnirtung
         Record found for city: pangnirtung    city id: 6096551
    Processing record 275 for the city: yulara
         Record found for city: yulara    city id: 6355222
    Processing record 276 for the city: rincon
         Record found for city: rincon    city id: 4218882
    Processing record 277 for the city: guerrero negro
         Record found for city: guerrero negro    city id: 4021858
    Processing record 278 for the city: simao
         Record found for city: simao    city id: 1794209
    Processing record 279 for the city: lorengau
         Record found for city: lorengau    city id: 2092164
    Processing record 280 for the city: asau
         No weather record found for city: asau
    ************************************************
    Processing record 281 for the city: torbay
         Record found for city: torbay    city id: 6167817
    Processing record 282 for the city: dujuma
         No weather record found for city: dujuma
    ************************************************
    Processing record 283 for the city: vao
         Record found for city: vao    city id: 588365
    Processing record 284 for the city: bulgan
         Record found for city: bulgan    city id: 2032201
    Processing record 285 for the city: mastic beach
         Record found for city: mastic beach    city id: 5126209
    Processing record 286 for the city: exeter
         Record found for city: exeter    city id: 2649808
    Processing record 287 for the city: isla mujeres
         Record found for city: isla mujeres    city id: 3526756
    Processing record 288 for the city: butterworth
         Record found for city: butterworth    city id: 1735076
    Processing record 289 for the city: halvad
         Record found for city: halvad    city id: 1270466
    Processing record 290 for the city: sinazongwe
         Record found for city: sinazongwe    city id: 897456
    Processing record 291 for the city: leonidion
         No weather record found for city: leonidion
    ************************************************
    Processing record 292 for the city: haines junction
         Record found for city: haines junction    city id: 5969025
    Processing record 293 for the city: deputatskiy
         Record found for city: deputatskiy    city id: 2028164
    Processing record 294 for the city: warrnambool
         Record found for city: warrnambool    city id: 2144528
    Processing record 295 for the city: atuona
         Record found for city: atuona    city id: 4020109
    Processing record 296 for the city: tainan
         Record found for city: tainan    city id: 1668355
    Processing record 297 for the city: graham
         Record found for city: graham    city id: 4468525
    Processing record 298 for the city: clyde river
         Record found for city: clyde river    city id: 5924351
    Processing record 299 for the city: ciudad bolivar
         Record found for city: ciudad bolivar    city id: 3645532
    Processing record 300 for the city: souillac
         Record found for city: souillac    city id: 3026644
    Processing record 301 for the city: hami
         Record found for city: hami    city id: 1529484
    Processing record 302 for the city: usinsk
         Record found for city: usinsk    city id: 863061
    Processing record 303 for the city: amahai
         Record found for city: amahai    city id: 1651591
    Processing record 304 for the city: ajdabiya
         Record found for city: ajdabiya    city id: 89113
    Processing record 305 for the city: kodiak
         Record found for city: kodiak    city id: 4407665
    Processing record 306 for the city: atasu
         Record found for city: atasu    city id: 1526041
    Processing record 307 for the city: wenling
         Record found for city: wenling    city id: 1791464
    Processing record 308 for the city: tezu
         Record found for city: tezu    city id: 1254709
    Processing record 309 for the city: sungai udang
         Record found for city: sungai udang    city id: 1735086
    Processing record 310 for the city: yerbogachen
         Record found for city: yerbogachen    city id: 2012956
    Processing record 311 for the city: saldanha
         Record found for city: saldanha    city id: 2737599
    Processing record 312 for the city: pallikonda
         No weather record found for city: pallikonda
    ************************************************
    Processing record 313 for the city: nalut
         Record found for city: nalut    city id: 2214433
    Processing record 314 for the city: najran
         Record found for city: najran    city id: 103630
    Processing record 315 for the city: lake city
         Record found for city: lake city    city id: 5427796
    Processing record 316 for the city: gorno-chuyskiy
         No weather record found for city: gorno-chuyskiy
    ************************************************
    Processing record 317 for the city: aasiaat
         Record found for city: aasiaat    city id: 3424901
    Processing record 318 for the city: mehamn
         Record found for city: mehamn    city id: 778707
    Processing record 319 for the city: gangotri
         No weather record found for city: gangotri
    ************************************************
    Processing record 320 for the city: katsuura
         Record found for city: katsuura    city id: 1865309
    Processing record 321 for the city: launceston
         Record found for city: launceston    city id: 2160517
    Processing record 322 for the city: isangel
         Record found for city: isangel    city id: 2136825
    Processing record 323 for the city: batagay
         Record found for city: batagay    city id: 2027044
    Processing record 324 for the city: taiyuan
         Record found for city: taiyuan    city id: 1793511
    Processing record 325 for the city: orje
         Record found for city: orje    city id: 3143427
    Processing record 326 for the city: lichuan
         Record found for city: lichuan    city id: 1803782
    Processing record 327 for the city: korla
         No weather record found for city: korla
    ************************************************
    Processing record 328 for the city: laguna
         Record found for city: laguna    city id: 4013704
    Processing record 329 for the city: ojinaga
         Record found for city: ojinaga    city id: 3994469
    Processing record 330 for the city: verkhoshizhemye
         Record found for city: verkhoshizhemye    city id: 474370
    Processing record 331 for the city: ossora
         Record found for city: ossora    city id: 2122389
    Processing record 332 for the city: saint-augustin
         Record found for city: saint-augustin    city id: 3031582
    Processing record 333 for the city: anqing
         Record found for city: anqing    city id: 1817993
    Processing record 334 for the city: sovetskaya
         Record found for city: sovetskaya    city id: 490065
    Processing record 335 for the city: hope mills
         Record found for city: hope mills    city id: 4471851
    Processing record 336 for the city: juneau
         Record found for city: juneau    city id: 5554072
    Processing record 337 for the city: beringovskiy
         Record found for city: beringovskiy    city id: 2126710
    Processing record 338 for the city: garden city
         Record found for city: garden city    city id: 5118226
    Processing record 339 for the city: raga
         No weather record found for city: raga
    ************************************************
    Processing record 340 for the city: sorland
         Record found for city: sorland    city id: 3137469
    Processing record 341 for the city: puerto asis
         Record found for city: puerto asis    city id: 3671549
    Processing record 342 for the city: ifakara
         Record found for city: ifakara    city id: 159492
    Processing record 343 for the city: nakamura
         Record found for city: nakamura    city id: 1856057
    Processing record 344 for the city: kutum
         Record found for city: kutum    city id: 371745
    Processing record 345 for the city: husavik
         Record found for city: husavik    city id: 5961417
    Processing record 346 for the city: bihoro
         Record found for city: bihoro    city id: 2127383
    Processing record 347 for the city: umm jarr
         No weather record found for city: umm jarr
    ************************************************
    Processing record 348 for the city: nizwa
         Record found for city: nizwa    city id: 286987
    Processing record 349 for the city: shiyan
         Record found for city: shiyan    city id: 1794903
    Processing record 350 for the city: camacupa
         Record found for city: camacupa    city id: 3351014
    Processing record 351 for the city: andros
         Record found for city: andros    city id: 265040
    Processing record 352 for the city: sambava
         Record found for city: sambava    city id: 1056899
    Processing record 353 for the city: rostaq
         No weather record found for city: rostaq
    ************************************************
    Processing record 354 for the city: luang prabang
         Record found for city: luang prabang    city id: 1655559
    Processing record 355 for the city: zapadnaya dvina
         Record found for city: zapadnaya dvina    city id: 464891
    Processing record 356 for the city: pamanukan
         Record found for city: pamanukan    city id: 1632998
    Processing record 357 for the city: lasa
         Record found for city: lasa    city id: 146639
    Processing record 358 for the city: blind river
         Record found for city: blind river    city id: 5903851
    Processing record 359 for the city: metro
         Record found for city: metro    city id: 1635283
    Processing record 360 for the city: veraval
         Record found for city: veraval    city id: 3031871
    Processing record 361 for the city: san quintin
         Record found for city: san quintin    city id: 1688687
    Processing record 362 for the city: sumbe
         Record found for city: sumbe    city id: 3346015
    Processing record 363 for the city: abu samrah
         Record found for city: abu samrah    city id: 172515
    Processing record 364 for the city: moerai
         Record found for city: moerai    city id: 4034188
    Processing record 365 for the city: ceuta
         Record found for city: ceuta    city id: 4002745
    Processing record 366 for the city: grand river south east
         No weather record found for city: grand river south east
    ************************************************
    Processing record 367 for the city: taksimo
         Record found for city: taksimo    city id: 2015701
    Processing record 368 for the city: sobolevo
         Record found for city: sobolevo    city id: 525426
    Processing record 369 for the city: ngaoundere
         Record found for city: ngaoundere    city id: 2224827
    Processing record 370 for the city: forestville
         Record found for city: forestville    city id: 6944112
    Processing record 371 for the city: evensk
         Record found for city: evensk    city id: 2125693
    Processing record 372 for the city: kavaratti
         Record found for city: kavaratti    city id: 1267390
    Processing record 373 for the city: flinders
         Record found for city: flinders    city id: 6255012
    Processing record 374 for the city: noumea
         Record found for city: noumea    city id: 2139521
    Processing record 375 for the city: harindanga
         Record found for city: harindanga    city id: 1349090
    Processing record 376 for the city: lake havasu city
         Record found for city: lake havasu city    city id: 5301388
    Processing record 377 for the city: biaora
         Record found for city: biaora    city id: 1275762
    Processing record 378 for the city: sol-iletsk
         Record found for city: sol-iletsk    city id: 491019
    Processing record 379 for the city: jiuquan
         Record found for city: jiuquan    city id: 1280957
    Processing record 380 for the city: dunedin
         Record found for city: dunedin    city id: 2191562
    Processing record 381 for the city: luanda
         Record found for city: luanda    city id: 2240449
    Processing record 382 for the city: longkou
         Record found for city: longkou    city id: 1802550
    Processing record 383 for the city: noyabrsk
         Record found for city: noyabrsk    city id: 1496503
    Processing record 384 for the city: ust-kulom
         Record found for city: ust-kulom    city id: 478050
    Processing record 385 for the city: gawler
         Record found for city: gawler    city id: 2071059
    Processing record 386 for the city: charters towers
         Record found for city: charters towers    city id: 2171722
    Processing record 387 for the city: poso
         Record found for city: poso    city id: 1630723
    Processing record 388 for the city: sfantu gheorghe
         Record found for city: sfantu gheorghe    city id: 667306
    Processing record 389 for the city: idrija
         Record found for city: idrija    city id: 3199171
    Processing record 390 for the city: puro
         Record found for city: puro    city id: 1706889
    Processing record 391 for the city: fukuma
         Record found for city: fukuma    city id: 1863978
    Processing record 392 for the city: dingle
         Record found for city: dingle    city id: 1714733
    Processing record 393 for the city: cayenne
         Record found for city: cayenne    city id: 3382160
    Processing record 394 for the city: kpandu
         Record found for city: kpandu    city id: 2299233
    Processing record 395 for the city: satitoa
         No weather record found for city: satitoa
    ************************************************
    Processing record 396 for the city: kidal
         Record found for city: kidal    city id: 2455290
    Processing record 397 for the city: erenhot
         Record found for city: erenhot    city id: 2037485
    Processing record 398 for the city: funtua
         Record found for city: funtua    city id: 2342490
    Processing record 399 for the city: kabare
         Record found for city: kabare    city id: 216281
    Processing record 400 for the city: barentu
         Record found for city: barentu    city id: 342711
    Processing record 401 for the city: kailua
         Record found for city: kailua    city id: 5847486
    Processing record 402 for the city: madang
         Record found for city: madang    city id: 2091996
    Processing record 403 for the city: eureka
         Record found for city: eureka    city id: 5563397
    Processing record 404 for the city: wajima
         Record found for city: wajima    city id: 1848976
    Processing record 405 for the city: uvalde
         Record found for city: uvalde    city id: 4738721
    Processing record 406 for the city: xinqing
         Record found for city: xinqing    city id: 2033667
    Processing record 407 for the city: yubari
         No weather record found for city: yubari
    ************************************************
    Processing record 408 for the city: toulepleu
         No weather record found for city: toulepleu
    ************************************************
    Processing record 409 for the city: aksu
         Record found for city: aksu    city id: 1524298
    Processing record 410 for the city: kindu
         Record found for city: kindu    city id: 212902
    Processing record 411 for the city: mahebourg
         Record found for city: mahebourg    city id: 934322
    Processing record 412 for the city: pishin
         Record found for city: pishin    city id: 1167821
    Processing record 413 for the city: antalya
         Record found for city: antalya    city id: 323777
    Processing record 414 for the city: provideniya
         Record found for city: provideniya    city id: 4031574
    Processing record 415 for the city: broome
         Record found for city: broome    city id: 2656067
    Processing record 416 for the city: dumai
         Record found for city: dumai    city id: 1645133
    Processing record 417 for the city: cabo san lucas
         Record found for city: cabo san lucas    city id: 3985710
    Processing record 418 for the city: necochea
         Record found for city: necochea    city id: 3430443
    Processing record 419 for the city: mae hong son
         Record found for city: mae hong son    city id: 1152222
    Processing record 420 for the city: nyagan
         Record found for city: nyagan    city id: 1496476
    Processing record 421 for the city: tabiauea
         No weather record found for city: tabiauea
    ************************************************
    Processing record 422 for the city: tuatapere
         Record found for city: tuatapere    city id: 2180815
    Processing record 423 for the city: buala
         Record found for city: buala    city id: 2109528
    Processing record 424 for the city: bolgar
         Record found for city: bolgar    city id: 570990
    Processing record 425 for the city: talakan
         Record found for city: talakan    city id: 2015686
    Processing record 426 for the city: kinanah
         No weather record found for city: kinanah
    ************************************************
    Processing record 427 for the city: perth
         Record found for city: perth    city id: 2640358
    Processing record 428 for the city: fallon
         Record found for city: fallon    city id: 5681948
    Processing record 429 for the city: tokur
         Record found for city: tokur    city id: 2015217
    Processing record 430 for the city: ankazoabo
         Record found for city: ankazoabo    city id: 1072879
    Processing record 431 for the city: kayerkan
         Record found for city: kayerkan    city id: 1497337
    Processing record 432 for the city: porbandar
         Record found for city: porbandar    city id: 1259395
    Processing record 433 for the city: epe
         Record found for city: epe    city id: 2756071
    Processing record 434 for the city: pitsunda
         Record found for city: pitsunda    city id: 615460
    Processing record 435 for the city: port-gentil
         Record found for city: port-gentil    city id: 2396518
    Processing record 436 for the city: honningsvag
         Record found for city: honningsvag    city id: 779554
    Processing record 437 for the city: shushtar
         Record found for city: shushtar    city id: 114584
    Processing record 438 for the city: naryan-mar
         Record found for city: naryan-mar    city id: 523392
    Processing record 439 for the city: boyolangu
         Record found for city: boyolangu    city id: 1648082
    Processing record 440 for the city: camacha
         Record found for city: camacha    city id: 2270385
    Processing record 441 for the city: amozoc
         No weather record found for city: amozoc
    ************************************************
    Processing record 442 for the city: altay
         Record found for city: altay    city id: 1529651
    Processing record 443 for the city: ust-kuyga
         Record found for city: ust-kuyga    city id: 2013921
    Processing record 444 for the city: solsvik
         No weather record found for city: solsvik
    ************************************************
    Processing record 445 for the city: raudeberg
         Record found for city: raudeberg    city id: 3146487
    Processing record 446 for the city: olafsvik
         No weather record found for city: olafsvik
    ************************************************
    Processing record 447 for the city: north platte
         Record found for city: north platte    city id: 5697939
    Processing record 448 for the city: algiers
         Record found for city: algiers    city id: 4335045
    Processing record 449 for the city: isla vista
         Record found for city: isla vista    city id: 5359864
    Processing record 450 for the city: poya
         Record found for city: poya    city id: 2138522
    Processing record 451 for the city: nyurba
         Record found for city: nyurba    city id: 2018735
    Processing record 452 for the city: sibolga
         Record found for city: sibolga    city id: 1213855
    Processing record 453 for the city: kabo
         Record found for city: kabo    city id: 2386042
    Processing record 454 for the city: licata
         Record found for city: licata    city id: 2524393
    Processing record 455 for the city: diu
         Record found for city: diu    city id: 1272502
    Processing record 456 for the city: labutta
         No weather record found for city: labutta
    ************************************************
    Processing record 457 for the city: rapid valley
         Record found for city: rapid valley    city id: 5768244
    Processing record 458 for the city: gwadar
         Record found for city: gwadar    city id: 1177446
    Processing record 459 for the city: nynashamn
         Record found for city: nynashamn    city id: 2687636
    Processing record 460 for the city: lagoa
         Record found for city: lagoa    city id: 2267254
    Processing record 461 for the city: goundi
         Record found for city: goundi    city id: 2431736
    Processing record 462 for the city: yinchuan
         Record found for city: yinchuan    city id: 1786657
    Processing record 463 for the city: alakurtti
         Record found for city: alakurtti    city id: 583472
    Processing record 464 for the city: bolshaya murta
         No weather record found for city: bolshaya murta
    ************************************************
    Processing record 465 for the city: carauari
         Record found for city: carauari    city id: 3664659
    Processing record 466 for the city: nizhnevartovsk
         Record found for city: nizhnevartovsk    city id: 1497543
    Processing record 467 for the city: bolungarvik
         No weather record found for city: bolungarvik
    ************************************************
    Processing record 468 for the city: ostersund
         Record found for city: ostersund    city id: 2685750
    Processing record 469 for the city: emba
         Record found for city: emba    city id: 146639
    Processing record 470 for the city: nishihara
         Record found for city: nishihara    city id: 1850144
    Processing record 471 for the city: ola
         Record found for city: ola    city id: 2122574
    Processing record 472 for the city: marystown
         Record found for city: marystown    city id: 6067472
    Processing record 473 for the city: atar
         Record found for city: atar    city id: 2381334
    Processing record 474 for the city: yarada
         Record found for city: yarada    city id: 1252783
    Processing record 475 for the city: mitsamiouli
         Record found for city: mitsamiouli    city id: 921786
    Processing record 476 for the city: kungurtug
         Record found for city: kungurtug    city id: 1501377
    Processing record 477 for the city: roma
         Record found for city: roma    city id: 6539761
    Processing record 478 for the city: sarangani
         Record found for city: sarangani    city id: 1687186
    Processing record 479 for the city: martapura
         Record found for city: martapura    city id: 1636022
    Processing record 480 for the city: buta
         Record found for city: buta    city id: 217570
    Processing record 481 for the city: keti bandar
         Record found for city: keti bandar    city id: 1174451
    Processing record 482 for the city: vysokogornyy
         Record found for city: vysokogornyy    city id: 2013216
    Processing record 483 for the city: ponta do sol
         Record found for city: ponta do sol    city id: 3453439
    Processing record 484 for the city: hudson bay
         Record found for city: hudson bay    city id: 5978133
    Processing record 485 for the city: mbandaka
         Record found for city: mbandaka    city id: 2312895
    Processing record 486 for the city: mandali
         Record found for city: mandali    city id: 93709
    Processing record 487 for the city: bargal
         No weather record found for city: bargal
    ************************************************
    Processing record 488 for the city: carberry
         Record found for city: carberry    city id: 5916706
    Processing record 489 for the city: tonstad
         Record found for city: tonstad    city id: 3134327
    Processing record 490 for the city: ilinskiy
         Record found for city: ilinskiy    city id: 557140
    Processing record 491 for the city: medyn
         Record found for city: medyn    city id: 527869
    Processing record 492 for the city: dir
         Record found for city: dir    city id: 2236015
    Processing record 493 for the city: zlobin
         Record found for city: zlobin    city id: 3191648
    Processing record 494 for the city: ilam
         Record found for city: ilam    city id: 130802
    Processing record 495 for the city: vanavara
         Record found for city: vanavara    city id: 2013727
    Processing record 496 for the city: lima
         Record found for city: lima    city id: 3936456
    Processing record 497 for the city: minab
         Record found for city: minab    city id: 123941
    Processing record 498 for the city: taoudenni
         Record found for city: taoudenni    city id: 2450173
    Processing record 499 for the city: talcahuano
         Record found for city: talcahuano    city id: 3870282
    Processing record 500 for the city: poronaysk
         Record found for city: poronaysk    city id: 2121909
    Processing record 501 for the city: rapar
         Record found for city: rapar    city id: 1258406
    Processing record 502 for the city: marsa matruh
         Record found for city: marsa matruh    city id: 352733
    Processing record 503 for the city: lidkoping
         Record found for city: lidkoping    city id: 2696329
    Processing record 504 for the city: port hawkesbury
         Record found for city: port hawkesbury    city id: 6111867
    Processing record 505 for the city: bandar
         Record found for city: bandar    city id: 1649593
    Processing record 506 for the city: svencioneliai
         Record found for city: svencioneliai    city id: 594067
    Processing record 507 for the city: louisbourg
         No weather record found for city: louisbourg
    ************************************************
    Processing record 508 for the city: banda aceh
         Record found for city: banda aceh    city id: 1215502
    Processing record 509 for the city: yakeshi
         Record found for city: yakeshi    city id: 2033536
    Processing record 510 for the city: northam
         Record found for city: northam    city id: 2641434
    Processing record 511 for the city: kaduy
         Record found for city: kaduy    city id: 554535
    Processing record 512 for the city: praia
         Record found for city: praia    city id: 3460954
    Processing record 513 for the city: hay river
         Record found for city: hay river    city id: 5972762
    Processing record 514 for the city: torrox
         Record found for city: torrox    city id: 2510245
    Processing record 515 for the city: maragogi
         Record found for city: maragogi    city id: 3395458
    Processing record 516 for the city: lastoursville
         Record found for city: lastoursville    city id: 2399870
    Processing record 517 for the city: kyra
         No weather record found for city: kyra
    ************************************************
    Processing record 518 for the city: istisu
         Record found for city: istisu    city id: 586320
    Processing record 519 for the city: lukulu
         Record found for city: lukulu    city id: 909488
    Processing record 520 for the city: kampong thum
         Record found for city: kampong thum    city id: 1831125
    Processing record 521 for the city: belaya gora
         Record found for city: belaya gora    city id: 2126785
    Processing record 522 for the city: bayan
         Record found for city: bayan    city id: 2030079
    Processing record 523 for the city: cocobeach
         Record found for city: cocobeach    city id: 2401357
    Processing record 524 for the city: bintulu
         Record found for city: bintulu    city id: 1737486
    Processing record 525 for the city: oranjestad
         Record found for city: oranjestad    city id: 3577154
    Processing record 526 for the city: gulfport
         Record found for city: gulfport    city id: 4428667
    Processing record 527 for the city: kununurra
         Record found for city: kununurra    city id: 2068110
    Processing record 528 for the city: floro
         Record found for city: floro    city id: 3156980
    Processing record 529 for the city: mezen
         Record found for city: mezen    city id: 527321
    Processing record 530 for the city: punta alta
         Record found for city: punta alta    city id: 3429886
    Processing record 531 for the city: acayucan
         Record found for city: acayucan    city id: 3533426
    Processing record 532 for the city: salalah
         Record found for city: salalah    city id: 286621
    Processing record 533 for the city: ormara
         Record found for city: ormara    city id: 1168700
    Processing record 534 for the city: erdemli
         No weather record found for city: erdemli
    ************************************************
    Processing record 535 for the city: ordu
         Record found for city: ordu    city id: 741100
    Processing record 536 for the city: gushikawa
         Record found for city: gushikawa    city id: 1863495
    Processing record 537 for the city: avanigadda
         Record found for city: avanigadda    city id: 1278122
    Processing record 538 for the city: oksfjord
         Record found for city: oksfjord    city id: 778362
    Processing record 539 for the city: shangrao
         Record found for city: shangrao    city id: 1787858
    Processing record 540 for the city: kismayo
         No weather record found for city: kismayo
    ************************************************
    Processing record 541 for the city: los llanos de aridane
         Record found for city: los llanos de aridane    city id: 2514651
    Processing record 542 for the city: aden
         Record found for city: aden    city id: 415189
    Processing record 543 for the city: rio gallegos
         Record found for city: rio gallegos    city id: 3838859
    Processing record 544 for the city: almaznyy
         Record found for city: almaznyy    city id: 582447
    Processing record 545 for the city: pacific grove
         Record found for city: pacific grove    city id: 5380437
    Processing record 546 for the city: blankenberge
         Record found for city: blankenberge    city id: 2801858
    Processing record 547 for the city: skjaerhollen
         No weather record found for city: skjaerhollen
    ************************************************
    Processing record 548 for the city: praia da vitoria
         Record found for city: praia da vitoria    city id: 3372760
    Processing record 549 for the city: bongandanga
         Record found for city: bongandanga    city id: 218229
    Processing record 550 for the city: axim
         Record found for city: axim    city id: 2303611
    Processing record 551 for the city: marhaura
         Record found for city: marhaura    city id: 1263528
    Processing record 552 for the city: sechura
         Record found for city: sechura    city id: 3691954
    Processing record 553 for the city: brasileia
         No weather record found for city: brasileia
    ************************************************
    Processing record 554 for the city: loandjili
         Record found for city: loandjili    city id: 2258378
    Processing record 555 for the city: mwinilunga
         Record found for city: mwinilunga    city id: 902620
    Processing record 556 for the city: chocaman
         Record found for city: chocaman    city id: 3530778
    Processing record 557 for the city: cagayan de tawi-tawi
         No weather record found for city: cagayan de tawi-tawi
    ************************************************
    Processing record 558 for the city: morwa
         Record found for city: morwa    city id: 1262734
    Processing record 559 for the city: langsa
         Record found for city: langsa    city id: 1214724
    Processing record 560 for the city: benguela
         Record found for city: benguela    city id: 3351663
    Processing record 561 for the city: grand gaube
         Record found for city: grand gaube    city id: 934479
    Processing record 562 for the city: szalkszentmarton
         Record found for city: szalkszentmarton    city id: 3044941
    Processing record 563 for the city: imbituba
         Record found for city: imbituba    city id: 3461370
    Processing record 564 for the city: macapa
         Record found for city: macapa    city id: 3396016
    Processing record 565 for the city: hirara
         Record found for city: hirara    city id: 1862505
    Processing record 566 for the city: chapais
         Record found for city: chapais    city id: 5919850
    Processing record 567 for the city: gorontalo
         Record found for city: gorontalo    city id: 1643837
    Processing record 568 for the city: havoysund
         Record found for city: havoysund    city id: 779622
    Processing record 569 for the city: srednekolymsk
         Record found for city: srednekolymsk    city id: 2121025
    Processing record 570 for the city: vikyrovice
         Record found for city: vikyrovice    city id: 3062909
    Processing record 571 for the city: turukhansk
         Record found for city: turukhansk    city id: 1488903
    Processing record 572 for the city: darnah
         Record found for city: darnah    city id: 87205
    Processing record 573 for the city: sabang
         Record found for city: sabang    city id: 1691355
    Processing record 574 for the city: sompeta
         Record found for city: sompeta    city id: 1255816
    Processing record 575 for the city: shimoda
         Record found for city: shimoda    city id: 1852357
    Processing record 576 for the city: kedrovyy
         Record found for city: kedrovyy    city id: 1538641
    Processing record 577 for the city: meyungs
         No weather record found for city: meyungs
    ************************************************
    Processing record 578 for the city: itarema
         Record found for city: itarema    city id: 3393692
    Processing record 579 for the city: kormilovka
         Record found for city: kormilovka    city id: 1502526
    Processing record 580 for the city: kazalinsk
         No weather record found for city: kazalinsk
    ************************************************
    Processing record 581 for the city: berbera
         No weather record found for city: berbera
    ************************************************
    Processing record 582 for the city: hamilton
         Record found for city: hamilton    city id: 3573197
    Processing record 583 for the city: moroni
         Record found for city: moroni    city id: 5543462
    Processing record 584 for the city: tekeli
         Record found for city: tekeli    city id: 1518296
    Processing record 585 for the city: andros town
         Record found for city: andros town    city id: 3572906
    Processing record 586 for the city: pelym
         Record found for city: pelym    city id: 1495385
    Processing record 587 for the city: damietta
         Record found for city: damietta    city id: 358048
    Processing record 588 for the city: burkhala
         No weather record found for city: burkhala
    ************************************************
    Processing record 589 for the city: bordighera
         Record found for city: bordighera    city id: 3181864
    Processing record 590 for the city: tual
         Record found for city: tual    city id: 1623197
    Processing record 591 for the city: cockenzie
         Record found for city: cockenzie    city id: 2652681
    Processing record 592 for the city: santa fe
         Record found for city: santa fe    city id: 3836277
    Processing record 593 for the city: port lincoln
         Record found for city: port lincoln    city id: 2063036
    Processing record 594 for the city: esna
         Record found for city: esna    city id: 675840
    Processing record 595 for the city: waupun
         Record found for city: waupun    city id: 5278106
    Processing record 596 for the city: khartoum
         Record found for city: khartoum    city id: 379252
    Processing record 597 for the city: dombarovskiy
         Record found for city: dombarovskiy    city id: 565407
    Processing record 598 for the city: miranda
         Record found for city: miranda    city id: 3674702
    Processing record 599 for the city: verkhnyaya inta
         Record found for city: verkhnyaya inta    city id: 1487332
    Processing record 600 for the city: batagay-alyta
         Record found for city: batagay-alyta    city id: 2027042
    Processing record 601 for the city: syasstroy
         Record found for city: syasstroy    city id: 485313
    Processing record 602 for the city: akropong
         Record found for city: akropong    city id: 2305027
    Processing record 603 for the city: along
         Record found for city: along    city id: 1278969
    Processing record 604 for the city: lolua
         No weather record found for city: lolua
    ************************************************
    Processing record 605 for the city: yar-sale
         Record found for city: yar-sale    city id: 1486321
    Processing record 606 for the city: karaton
         Record found for city: karaton    city id: 1630058
    Processing record 607 for the city: petropavlovsk-kamchatskiy
         Record found for city: petropavlovsk-kamchatskiy    city id: 2122104
    Processing record 608 for the city: dawlatabad
         Record found for city: dawlatabad    city id: 1142226
    Processing record 609 for the city: faanui
         Record found for city: faanui    city id: 4034551
    Processing record 610 for the city: riyadh
         Record found for city: riyadh    city id: 108410
    Processing record 611 for the city: winston
         Record found for city: winston    city id: 2636561
    Processing record 612 for the city: arica
         Record found for city: arica    city id: 3899361
    Processing record 613 for the city: springfield
         Record found for city: springfield    city id: 4409896
    Processing record 614 for the city: tommot
         Record found for city: tommot    city id: 2015179
    Processing record 615 for the city: shenjiamen
         Record found for city: shenjiamen    city id: 1795632
    Processing record 616 for the city: ejido
         Record found for city: ejido    city id: 3644417
    Processing record 617 for the city: chuy
         Record found for city: chuy    city id: 3443061
    Processing record 618 for the city: coquimbo
         Record found for city: coquimbo    city id: 3893629
    Processing record 619 for the city: liuhe
         Record found for city: liuhe    city id: 2036033
    Processing record 620 for the city: lodwar
         Record found for city: lodwar    city id: 189280
    Processing record 621 for the city: sept-iles
         Record found for city: sept-iles    city id: 6144312
    Processing record 622 for the city: kodinsk
         Record found for city: kodinsk    city id: 1503037
    Processing record 623 for the city: cusuna
         Record found for city: cusuna    city id: 3612949
    Processing record 624 for the city: kazerun
         Record found for city: kazerun    city id: 128321
    Processing record 625 for the city: dawei
         Record found for city: dawei    city id: 1293625
    Processing record 626 for the city: linares
         Record found for city: linares    city id: 3883167
    Processing record 627 for the city: quchan
         Record found for city: quchan    city id: 119115
    Processing record 628 for the city: lompoc
         Record found for city: lompoc    city id: 5367788
    Processing record 629 for the city: buluang
         Record found for city: buluang    city id: 1717512
    Processing record 630 for the city: jadu
         Record found for city: jadu    city id: 2216432
    Processing record 631 for the city: kangasala
         Record found for city: kangasala    city id: 654441
    Processing record 632 for the city: vila
         Record found for city: vila    city id: 3164565
    Processing record 633 for the city: seligenstadt
         Record found for city: seligenstadt    city id: 2833242
    Processing record 634 for the city: mokhsogollokh
         Record found for city: mokhsogollokh    city id: 2019867
    Processing record 635 for the city: la union
         Record found for city: la union    city id: 3593500
    Processing record 636 for the city: mountain home
         Record found for city: mountain home    city id: 5601615
    Processing record 637 for the city: turayf
         Record found for city: turayf    city id: 101312
    Processing record 638 for the city: waingapu
         Record found for city: waingapu    city id: 1622318
    Processing record 639 for the city: bubaque
         Record found for city: bubaque    city id: 2374583
    Processing record 640 for the city: dudinka
         Record found for city: dudinka    city id: 1507116
    Processing record 641 for the city: cataingan
         Record found for city: cataingan    city id: 1717994
    Processing record 642 for the city: lianzhou
         Record found for city: lianzhou    city id: 1803841
    Processing record 643 for the city: lanzhou
         Record found for city: lanzhou    city id: 1804430
    Processing record 644 for the city: westerland
         Record found for city: westerland    city id: 2757220
    Processing record 645 for the city: brooks
         Record found for city: brooks    city id: 5909514
    Processing record 646 for the city: karratha
         Record found for city: karratha    city id: 6620339
    Processing record 647 for the city: bucerias
         Record found for city: bucerias    city id: 4016734
    Processing record 648 for the city: luba
         Record found for city: luba    city id: 1705460
    Processing record 649 for the city: alugan
         Record found for city: alugan    city id: 1731248
    Processing record 650 for the city: nyrad
         Record found for city: nyrad    city id: 2615932
    


```python
#len(search_data)#len(se 
lat_data = [data.get("coord").get("lat") for data in search_data]
lng_data = [data.get("coord").get("lon") for data in search_data]
temp_data = [data.get("main").get("temp") for data in search_data]
humid_data = [data.get("main").get("humidity") for data in search_data]
cloud_data =[data.get("clouds").get("all") for data in search_data]
wind_data = [data.get("wind").get("speed") for data in search_data]
weather_data = pd.DataFrame({"cityName":cityList,
                            "country":countryList,
                            "lat":lat_data,
                            "lng":lng_data,
                            "temp":temp_data,
                            "humidity":humid_data,
                            "cloudiness":cloud_data,
                            "winds":wind_data})
```


```python
weather_data = weather_data[["cityName","country","lat","lng","temp","humidity","cloudiness","winds"]]
weather_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>cityName</th>
      <th>country</th>
      <th>lat</th>
      <th>lng</th>
      <th>temp</th>
      <th>humidity</th>
      <th>cloudiness</th>
      <th>winds</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>gobabis</td>
      <td>na</td>
      <td>-22.45</td>
      <td>18.97</td>
      <td>37.02</td>
      <td>59</td>
      <td>0</td>
      <td>4.14</td>
    </tr>
    <tr>
      <th>1</th>
      <td>nadym</td>
      <td>ru</td>
      <td>65.53</td>
      <td>72.51</td>
      <td>56.01</td>
      <td>100</td>
      <td>48</td>
      <td>11.97</td>
    </tr>
    <tr>
      <th>2</th>
      <td>santa cruz</td>
      <td>us</td>
      <td>36.97</td>
      <td>-122.03</td>
      <td>74.98</td>
      <td>72</td>
      <td>90</td>
      <td>8.05</td>
    </tr>
    <tr>
      <th>3</th>
      <td>hobart</td>
      <td>au</td>
      <td>-42.88</td>
      <td>147.33</td>
      <td>48.20</td>
      <td>70</td>
      <td>40</td>
      <td>10.29</td>
    </tr>
    <tr>
      <th>4</th>
      <td>pevek</td>
      <td>ru</td>
      <td>69.70</td>
      <td>170.27</td>
      <td>35.49</td>
      <td>92</td>
      <td>24</td>
      <td>4.36</td>
    </tr>
  </tbody>
</table>
</div>




```python
#len(search_data)#len(se 
lat_data = [data.get("coord").get("lat") for data in search_data]
lng_data = [data.get("coord").get("lon") for data in search_data]
temp_data = [data.get("main").get("temp") for data in search_data]
humid_data = [data.get("main").get("humidity") for data in search_data]
cloud_data =[data.get("clouds").get("all") for data in search_data]
wind_data = [data.get("wind").get("speed") for data in search_data]
weather_data = pd.DataFrame({"cityName":cityList,
                            "country":countryList,
                            "lat":lat_data,
                            "lng":lng_data,
                            "temp":temp_data,
                            "humidity":humid_data,
                            "cloudiness":cloud_data,
                            "winds":wind_data})
```


```python
weather_data.to_csv("weatherdata.csv", encoding="utf-8", index=False)
```


```python
# Latitude vs Max Temp# Latit 
plt.scatter(weather_data["lat"], weather_data["temp"], marker="x")

# Add chart labels
plt.title("City Latitude vs Max Temperature")
plt.ylabel("Temperature (F) ")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim(-90,90)

# Save the figure
plt.savefig("Lat_vs_MaxTemp.png")
# Show plot
plt.show()
```


![png](output_9_0.png)



```python
# Latitude vs Cloudiness
plt.scatter(weather_data["lat"], weather_data["cloudiness"], marker="x")

# Add chart labels
plt.title("City Latitude vs Cloudiness")
plt.ylabel("Cloudiness")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim(-90,90)

# Save the figure
plt.savefig("Lat_vs_Cloudiness.png")

# Show plot
plt.show()
```


![png](output_10_0.png)



```python
# Latitude vs Wind Speed
plt.scatter(weather_data["lat"], weather_data["winds"], marker="o")

# Add chart labels
plt.title("City Latitude vs Wind Speed")
plt.ylabel("Wind Speed (mph)")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim(-90,90)

# Save the figure
plt.savefig("Lat_vs_WindSpeed.png")

# Show plot
plt.show()
```


![png](output_11_0.png)



```python
# Latitude vs Humidity
plt.scatter(weather_data["lat"], weather_data["humidity"], marker="o")

# Add chart labels
plt.title("City Latitude vs Humidity")
plt.ylabel("Humidity")
plt.xlabel("Latitude")
plt.grid(True)
plt.xlim(-90,90)

# Save the figure
plt.savefig("Lat_vs_Humidity.png")

# Show plot
plt.show()
```


![png](output_12_0.png)

